# Labryo LIMS — Comprehensive Project Context & Engineering Handoff
> **Last updated:** 2026-11-01 10:28 UTC  
> **Target Audience:** External Senior Full-Stack & Desktop Engineers  
> **Project Root:** `d:\lab`  
> **Current Version:** `2.0.9` (Modern x64) / `2.0.9` (Universal Legacy ia32)

---

## 1. What the App Is & Architectural Overview

**Labryo LIMS (Laboratory Information Management System)** is a mission-critical, full-featured clinical laboratory management platform designed specifically for medical diagnostic laboratories and clinics in Iraq and the Middle East. It is structured as an enterprise **Monorepo** (using npm workspaces) with a **Modular Monolith** and **Feature-Sliced Design (FSD)** frontend architecture.

### Primary Capabilities:
1. **Intake & Reception:** Fast registration of patients, age calculation (years/months/days), clinical doctor referrals, and test ordering with real-time tube grouping and barcode generation.
2. **Clinical Workstations & Results Entry:** Unified clinical console with dedicated workstations for multi-analyte chemistry, automated qualitative options, and specialized clinical forms (General Urine Examination [G.U.E], General Stool Examination [G.S.E], Complete Blood Count [CBC], Seminal Fluid Analysis [SFA], Total β-HCG, AMH, Blood Film, Body Fluids, Stone Analysis, Coagulation Profile, OGTT Curve).
3. **Clinical Intelligence & Safety:** Automatic reference range matching based on patient age, gender, and unit; critical panic value highlighting, historical delta checks, eGFR calculation, Friedewald LDL formula, and clinical guardrails before report printing.
4. **Report Design & Multi-Format Printing:** Real-time WYSIWYG paper designer (`PaperDesignerV2`) allowing live margin adjustments, bilingual header designs, custom logo placement, watermarks, normal range scoping, and pixel-perfect server-side rendering via Puppeteer (HTML, PDF, and high-resolution JPEG/PNG cards).
5. **Medical Device Connectivity (LIS Bridge):** Embedded background daemon (`0.0.0.0:5000`) supporting ASTM E1381/E1394 and HL7 2.x standards to receive results directly from clinical analyzers (Mindray, Sysmex, Beckman, Roche, etc.) without third-party middleware.
6. **Financials & Shift Management:** Cash drawer shift opening/closing, multi-currency support (IQD / USD), debt tracking, expense logging, doctor commissions, and financial summaries.
7. **Offline-First & LAN Multi-Workstation Synchronization:** Complete offline functionality with local SQLite storage, accompanied by an SSE (Server-Sent Events) real-time event bus allowing multiple PCs and tablets on the laboratory's local network (LAN) to collaborate concurrently with zero cloud dependency.

---

## 2. Tech Stack & Exact Versions

| Layer / Technology | Package / Tool | Version | Role in Labryo |
| :--- | :--- | :--- | :--- |
| **Monorepo Architecture** | npm workspaces | 3 (`package-lock.json` v3) | Orchestrates `apps/*` and `packages/*` |
| **Frontend Framework** | `next` (App Router) | `14.2.1` | SSR & client routes (`apps/web`), standalone output |
| **UI Library** | `react`, `react-dom` | `18.2.0` | Client component rendering, hooks, state management |
| **Iconography & Styling** | `lucide-react`, Tailwind CSS | `^0.368.0`, PostCSS | Clinical iconography, responsive styling, RTL support |
| **Desktop Runtime (Modern)** | `electron` | `30.0.1` | Windows 10/11 x64 desktop container |
| **Desktop Runtime (Legacy)** | `electron` (ia32) | `22.3.27` | Windows 7 SP1 / 8 / 32-bit compatibility container |
| **Desktop Packaging** | `electron-builder` | `^24.13.3` | NSIS installer generation, code compression, portable builds |
| **Auto-Updater** | `electron-updater` | `^6.8.9` | Differential updates from GitHub Releases (`hasden1999/lab-releases`) |
| **Backend Server** | `fastify` | `^4.26.2` | High-throughput local REST API & device ingestion |
| **ORM & Database Layer** | `prisma`, `@prisma/client` | `5.12.1` | SQLite schema management, type-safe queries, WAL pragmas |
| **Database Engine** | SQLite (WAL mode) | SQLite 3 | Embedded local database (`lab.db`), `PRAGMA user_version = 145` |
| **Headless PDF/Image Engine** | `puppeteer` | `^22.6.5` | Headless Chrome for medical report PDF & PNG generation |
| **Messaging / WhatsApp** | `@whiskeysockets/baileys` | `^6.7.24` | Background headless WhatsApp Web multi-device bridge |
| **Language & Transpilation**| `typescript`, `tsx` | `5.4.5`, `^4.7.2` | Strict typechecking across packages and live TS script execution |
| **Runtime Target** | Node.js | `v18.20.7` / `v20.x` | Embedded Node runtime bundled inside Desktop Engine |

---

## 3. How the App Operates: Offline, Storage & Build/Release

### 3.1 Offline Operation & Dual-Engine Architecture
1. **Fully Autonomous Local Operation:** Labryo does not require an active internet connection to execute any core function (intake, test ordering, result entry, analysis, printing, device communication, or financial shifts).
2. **Desktop Boot Process (`apps/desktop/main.js`):**
   - When launched, Electron starts `StartupTracer`, initializes an animated Arabic/English splash screen, and resolves an available HTTP port (default `8080`, with fallback ports `[8080, 8085, 8088, 8090, 8180, 3080, 3880]`).
   - It checks whether it is running in packaged production (`process.resourcesPath/engine`) or development mode.
   - It ensures the SQLite database (`lab.db`) exists in the user's roaming directory:
     `%APPDATA%\com.labryo.lims\lab.db` (or `%APPDATA%\Labryo LIMS\lab.db`).
   - If missing, it synchronously copies a clean template database from `engine/standalone/.../lab.db`.
   - It sets environment variable `DATABASE_URL="file:" + userSqliteDb` and spawns the bundled `engine/node.exe` executing `standalone/apps/web/server.js`.
   - Once the local HTTP server responds with HTTP 200 on `/ready` or `/api/health`, Electron reveals the main application window and terminates the splash screen.
3. **Universal Legacy Support (Windows 7 SP1 / ia32):**
   - For legacy 32-bit systems (Windows 7/8/10 32-bit), a custom binary patch was applied to `node.exe` PE import table (redirecting unsupported Win8+ API `EventSetInformation` to `EventRegister` in `advapi32.dll`) preventing Windows loader crashes.
   - Legacy channel runs Electron 22 (`apps/desktop/electron-builder-legacy.json`) with memory capped at 768MB and `NODE_SKIP_PLATFORM_CHECK=1`.

### 3.2 Data Storage Layer
- **Primary Database:** SQLite 3 in WAL (Write-Ahead Logging) mode, accessed via Prisma ORM (`apps/server/prisma/schema.prisma` and `apps/web/src/lib/prisma.ts`).
- **Pragmas Initialized at Startup (`initDbWAL` in `apps/web/src/lib/prisma.ts`):**
  - `PRAGMA journal_mode = WAL;`
  - `PRAGMA synchronous = NORMAL;`
  - `PRAGMA busy_timeout = 5000;`
  - `PRAGMA cache_size = -64000;` (64 MB in-memory cache)
  - `PRAGMA temp_store = MEMORY;`
  - `PRAGMA foreign_keys = ON;`
- **Runtime Schema Versioning:** Handled via SQLite `PRAGMA user_version`. Currently at `CURRENT_SCHEMA_VERSION = 145`. When a newer version of Labryo runs, `migrateDbPragmasAndColumns()` executes safe additive `ALTER TABLE` statements and `CREATE TABLE IF NOT EXISTS` for tables such as `Specialty`, `TestGroup`, and `ReferenceRange`, without requiring destructive migrations.
- **In-Memory / JSON Fallback Store (`apps/web/src/lib/serverStore.ts` & `sqliteSync.ts`):**
  - On 32-bit architecture (`process.arch === 'ia32'`), SQLite sync is safely bypassed to avoid memory exhaustion, falling back to atomic file-backed JSON (`lab_store.json`).
  - On 64-bit systems, `sqliteSync.ts` performs bidirectional synchronization between Prisma SQLite models and the in-memory fast access store.

### 3.3 Builds, Releases & Auto-Update Mechanism
- **Build Scripts:**
  - `npm run build`: Generates Prisma client and executes `next build` with Next.js standalone output.
  - `npm run desktop:dist`: Uses `electron-builder` to package NSIS installers for Windows x64.
  - `node tools/deploy/publish_desktop_release.js`: Verifies PE executable signatures, computes SHA-512 hashes, generates blockmaps, and publishes artifacts to GitHub Releases.
- **Update Channels (`apps/desktop/services/updateService.js`):**
  - **`stable`:** Production channel for modern 64-bit Windows systems (reads `latest.yml` / `stable.yml`).
  - **`legacy`:** Isolated channel for Windows 7 / 32-bit installations (reads `legacy.yml`), preventing legacy machines from auto-updating to 64-bit binaries.
  - **`beta`:** Pre-release channel for testing upcoming laboratory features.
- **Update Loop Guard:** `updateService.js` tracks update history and checksums in `updater_settings.json`. If an update fails to install or triggers repeated downloads of the same version, `isLoopLocked` activates, surfacing a manual download link and preventing infinite update loops.

---

## 4. Architecture Overview & Folder Structure

```
d:\lab\
├── apps\
│   ├── desktop\                      # Electron container for Windows desktop packaging
│   │   ├── main.js                   # Desktop entry point: process lifecycle, splash, port fallback
│   │   ├── preload.js                # IPC bridge exposing electronDesktop API to web renderer
│   │   ├── electron-builder-legacy.json # Legacy 32-bit Windows 7 packaging configuration
│   │   ├── package.json              # Desktop dependencies and electron-builder modern config
│   │   └── services\
│   │       ├── updateService.js      # Multi-channel auto-updater (stable/legacy/beta) & loop guard
│   │       ├── deviceBridgeService.js# Background LIS daemon manager for ASTM/HL7 analyzers
│   │       └── whatsappAutoPaste.ps1 # Native Windows clipboard paste bridge for WhatsApp
│   │
│   ├── server\                       # Fastify backend service
│   │   ├── src\
│   │   │   ├── index.ts              # Fastify server boot, CORS, JWT registration, route hooks
│   │   │   ├── prisma.ts             # Prisma client instance for Fastify services
│   │   │   ├── routes\               # REST endpoints (auth, patients, samples, tests, devices)
│   │   │   ├── services\             # Device TCP engine and WhatsApp Baileys service
│   │   │   └── utils\                # ASTM/HL7 parsers, audit logger, Ed25519 licensing
│   │   └── prisma\
│   │       ├── schema.prisma         # Authoritative database schema definition
│   │       └── seed.ts               # Initial database seed script (catalog, default admin staff)
│   │
│   └── web\                          # Next.js 14 App Router frontend and full-stack API
│       ├── next.config.js            # Standalone output, outputFileTracingRoot, asset redirects
│       ├── src\
│       │   ├── app\                  # Route endpoints and page definitions
│       │   │   ├── page.tsx          # Intake & Registration console (renders UnifiedWorkspace)
│       │   │   ├── patients\page.tsx # Patient records, visit history, sample search & print
│       │   │   ├── results\page.tsx  # Results workstation view (re-exports patients page)
│       │   │   ├── samples\page.tsx  # Samples list view (re-exports patients page)
│       │   │   ├── catalog\page.tsx  # Medical test catalog, reference ranges, panels & pricing
│       │   │   ├── settings\page.tsx # Laboratory profile, print header styles, units, currencies
│       │   │   ├── doctors\page.tsx  # Referring doctors management and financial tracking
│       │   │   ├── financials\page.tsx # Daily cash shifts, revenues, expenses & debts
│       │   │   ├── devices\page.tsx  # Analyzer connection status, port config, ASTM/HL7 mapping
│       │   │   ├── connect\page.tsx  # LAN client device pairing screen (tablets, reception PCs)
│       │   │   ├── login\page.tsx    # Staff authentication screen
│       │   │   ├── staff\page.tsx    # Staff management (roles: OWNER, TECHNICIAN, RECEPTION)
│       │   │   ├── verify\[id]\      # Public QR-code report verification endpoint
│       │   │   └── api\              # Next.js Route Handlers (samples, tests, print, pdf, etc.)
│       │   │
│       │   ├── widgets\unified-workspace\ # All-in-One Clinical Console (FSD Widget)
│       │   │   ├── index.ts          # Public API for unified workspace
│       │   │   ├── model\            # Custom hooks (`useUnifiedWorkspace`) & TypeScript contracts
│       │   │   ├── lib\              # Tube classifier, catalog ordering, keyboard shortcuts
│       │   │   └── ui\               # PatientCardPanel, CatalogCartPanel, ResultsGridPanel, ActionBar
│       │   │
│       │   ├── features\             # Feature-Sliced Design isolated domain features
│       │   │   └── manage-logo\      # Logo upload, alignment, sizing, and print preview
│       │   │
│       │   ├── components\           # React components and clinical modals
│       │   │   ├── AppShell.tsx      # Main layout wrapper, navigation header, status indicators
│       │   │   ├── LabContext.tsx    # Laboratory profile context (name, phone, address, currency)
│       │   │   ├── NetworkSyncProvider.tsx # Real-time SSE event subscriber & LAN state sync
│       │   │   ├── UrineFormModal.tsx# Specialized G.U.E form modal
│       │   │   ├── workstations\     # Clinical workstation modals (CBC, Stool, Semen, AMH, etc.)
│       │   │   ├── catalog\          # ReferenceRangesEditor and test parameters
│       │   │   ├── workspace\        # PaperDesignerV2 (WYSIWYG layout designer)
│       │   │   └── common\           # Reusable inputs (ClinicalAgeInput, ReferringDoctorSelect)
│       │   │
│       │   └── lib\                  # Frontend and shared utility library
│       │       ├── api.ts            # Client fetch wrapper with auto-auth and device token
│       │       ├── prisma.ts         # Prisma client, SQLite WAL pragmas, runtime auto-migrations
│       │       ├── testClassifier.ts # Central test classifier routing tests to specialized forms
│       │       ├── formatters.ts     # Bilingual number, age, date, and unit formatters
│       │       ├── serverStore.ts    # High-performance in-memory cache and file store
│       │       ├── sqliteSync.ts     # Prisma-to-memory bidirectional synchronization
│       │       ├── puppeteerPdfGenerator.ts # Server-side report PDF generator
│       │       └── shareReportToWhatsApp.ts # 3-tier WhatsApp sharing engine
│       └── prisma\
│           └── schema.prisma         # Client-side synchronized Prisma schema
│
├── packages\                         # Monorepo shared domain packages
│   ├── core\                         # Version constants (`APP_VERSION`), shared types
│   ├── domain\                       # Clinical formulas (eGFR, Friedewald LDL, ageUtils, ranges)
│   ├── data\                         # Default medical catalog dictionary (650+ clinical tests)
│   ├── forms\                        # Generic form rendering engine & JSON definitions (CBC, GSE, GUE)
│   ├── reports\                      # Report data builders and print layout structures
│   ├── design\                       # Design tokens (RTL typography, clinical colors, badges)
│   ├── messaging\                    # WhatsApp bilingual message formatting templates
│   └── shared\                       # Global cross-package utility primitives
│
├── tools\deploy\                     # Deployment, backup, rollback, and release automation scripts
│   ├── publish_desktop_release.js    # Automated release publisher to GitHub Releases
│   ├── backup.js & rollback.js       # Pre-deployment backup and emergency recovery
│   └── run_migrations.ps1            # Database schema push and integrity verification
│
├── scripts\                          # Maintenance and migration utilities
│   ├── merge_duplicates.js           # Deduplicates catalog tests with historical results preservation
│   ├── migrate_reference_ranges.js   # Migrates legacy reference string formats into relational ranges
│   └── license-keygen.mjs            # Ed25519 license key generation utility
│
└── handoff\                          # Handoff package for external engineers
    ├── TREE.txt                      # Complete filtered repository file tree
    ├── PROJECT_CONTEXT.md            # This authoritative architectural handoff document
    ├── MANIFEST.md                   # Full catalog of copied source files and purposes
    └── files\                        # Verbatim source files preserving relative directory structure
```

---

## 5. THE CHANGE MAP (Master Engineering Reference)

This table defines exactly where to make any future change in Labryo, which files depend on those changes, which database tables are involved, and what hazards/breakages must be guarded against.

| Feature Area | Files to Edit | Files That Depend on Them | DB Tables Involved (Prisma) | What Could Break If Changed |
| :--- | :--- | :--- | :--- | :--- |
| **Reception & Patient Registration** | `apps/web/src/widgets/unified-workspace/ui/PatientCardPanel.tsx`<br>`apps/web/src/widgets/unified-workspace/model/useUnifiedWorkspace.ts`<br>`apps/web/src/app/api/patients/route.ts`<br>`apps/web/src/components/common/ClinicalAgeInput.tsx` | `UnifiedWorkspace.tsx`<br>`apps/web/src/app/page.tsx`<br>`apps/web/src/app/patients/page.tsx` | `Patient`<br>`Sample`<br>`ReferringDoctor` | Input focus loss on re-render; age-to-birthdate parsing mismatch; patient duplicate creation if national ID or phone is improperly formatted; silent failure in LAN auto-save. |
| **Results Entry & Clinical Grid** | `apps/web/src/widgets/unified-workspace/ui/ResultsGridPanel.tsx`<br>`apps/web/src/app/api/samples/[id]/results/route.ts`<br>`apps/web/src/lib/qualitativeResultOptions.ts`<br>`apps/web/src/lib/deltaCheck.ts` | `UnifiedWorkspace.tsx`<br>`apps/web/src/app/patients/page.tsx`<br>`apps/web/src/app/results/page.tsx` | `SampleTest`<br>`Sample`<br>`TestCatalog`<br>`ReferenceRange` | Breaking keyboard navigation (`Enter` / `Arrow` keys); incorrect critical panic value trigger; failing to persist qualitative pill selections; breaking the `@@unique([sampleId, testId])` constraint. |
| **Workstation Routing & Special Forms Dispatch** | `apps/web/src/lib/testClassifier.ts`<br>`apps/web/src/widgets/unified-workspace/ui/ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/api/samples/[id]/print/route.ts`<br>`apps/web/src/lib/shareReportToWhatsApp.ts` | `TestCatalog`<br>`SampleTest` | Tests opening the wrong modal (e.g. stool instead of urine); test names in Arabic failing substring match; print template rendering standard tabular layout instead of specialized 2-column medical form. |
| **General Urine Examination (G.U.E)** | `apps/web/src/components/UrineFormModal.tsx`<br>`apps/web/src/lib/clinicalTemplatesConfig.ts`<br>`packages/forms/definitions/urine.json`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx`<br>`apps/web/src/app/api/samples/[id]/print/route.ts` | `SampleTest` (stores JSON string in `resultValue`) | Corrupting JSON structure stored in `resultValue`; microscopic examination pills (pus cells, RBCs, crystals) failing to save or breaking print layout. |
| **General Stool Examination (G.S.E)** | `apps/web/src/components/workstations/GseModal.tsx`<br>`packages/forms/definitions/stool.json`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx`<br>`apps/web/src/app/api/samples/[id]/print/route.ts` | `SampleTest` (`resultValue` JSON) | Parasite/worm stage dropdown options failing to serialize; print engine omitting physical vs microscopic stool sections. |
| **Complete Blood Count (CBC)** | `apps/web/src/components/workstations/CbcModal.tsx`<br>`packages/forms/definitions/cbc.json`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx`<br>`apps/web/src/app/api/samples/[id]/print/route.ts` | `SampleTest`<br>`ReferenceRange` | Automatic differential count (Neutrophils, Lymphocytes, etc.) sum validation errors; index calculation breakdown (MCV, MCH, MCHC); PDF truncation across pages. |
| **Seminal Fluid Analysis (SFA)** | `apps/web/src/components/workstations/SemenFormModal.tsx`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx` | `SampleTest` (`resultValue` JSON) | WHO 5th vs 6th edition reference range mismatch; motility calculation percentages failing to sum to 100%. |
| **Endocrine & Hormones (AMH & Total β-HCG)** | `apps/web/src/components/workstations/AmhFormModal.tsx`<br>`apps/web/src/components/workstations/BhcgFormModal.tsx`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx` | `SampleTest`<br>`ReferenceRange` | Gestational age interpretation table misaligning on print; ovarian reserve categorization failing for non-standard age ranges. |
| **Specialized Workstations (Blood Film, Body Fluids, Stone, Coag, OGTT)** | `apps/web/src/components/workstations/ClinicalFormWorkstationModal.tsx`<br>`apps/web/src/lib/testClassifier.ts`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts` | `ResultsGridPanel.tsx`<br>`apps/web/src/app/patients/page.tsx` | `SampleTest` | Failing to parse specialized clinical JSON structures; missing time-interval points in OGTT glucose tolerance curve. |
| **Medical Test Catalog & Test Panels** | `apps/web/src/app/catalog/page.tsx`<br>`apps/web/src/app/api/tests/route.ts`<br>`apps/web/src/app/api/tests/[id]/route.ts`<br>`apps/web/src/lib/catalogCache.ts`<br>`packages/data/src/catalog/catalogData.ts` | `PatientCardPanel.tsx`<br>`CatalogCartPanel.tsx`<br>`ResultsGridPanel.tsx`<br>`apps/web/src/app/api/samples/route.ts` | `TestCatalog`<br>`TestPanel`<br>`TestPanelItem`<br>`Specialty`<br>`TestGroup` | Catalog cache staleness (`catalogCache.ts`); duplicate test insertion; price changes not reflecting in existing unpaid samples; deleting a test referenced in historical sample tests. |
| **Multi-Tier Reference Ranges** | `apps/web/src/components/catalog/ReferenceRangesEditor.tsx`<br>`packages/domain/src/rangeClassification.ts`<br>`apps/web/src/lib/orderHelpers.ts`<br>`apps/server/prisma/schema.prisma` | `ResultsGridPanel.tsx`<br>`PrintBody.ts`<br>`apps/web/src/app/catalog/page.tsx` | `ReferenceRange`<br>`TestCatalog` | Sex-specific ('male'/'female'/'any') or age-bracket (`ageMin`/`ageMax` in days/months/years) matching failure; flag H/L (High/Low) incorrect calculation. |
| **Report Printing, Layout & PDF Engine** | `apps/web/src/app/api/samples/[id]/print/route.ts`<br>`apps/web/src/app/api/samples/[id]/print/PrintHeader.ts`<br>`apps/web/src/app/api/samples/[id]/print/PrintBody.ts`<br>`apps/web/src/lib/puppeteerPdfGenerator.ts`<br>`apps/web/src/lib/puppeteerLauncher.ts` | `apps/web/src/app/patients/page.tsx`<br>`UnifiedActionBar.tsx`<br>`apps/web/src/lib/shareReportToWhatsApp.ts` | `Settings`<br>`Sample`<br>`Patient`<br>`SampleTest` | Chromium headless spawn crash; page-break inside table rows or between test groups; logo aspect ratio distortion; missing fonts in legacy Windows 7 print rendering. |
| **Form Design & Paper Designer** | `apps/web/src/components/workspace/PaperDesignerV2.tsx`<br>`apps/web/src/features/manage-logo/ui/LogoSettingsControl.tsx`<br>`apps/web/src/app/api/settings/route.ts` | `PrintHeader.ts`<br>`PrintBody.ts`<br>`apps/web/src/components/LabContext.tsx` | `Settings` | Layout shift (CLS) during state hydration; logo coordinate offsets (`logoOffsetXMm`, `logoOffsetYMm`) not scaling in print preview; watermark opacity issues. |
| **Referring Doctors** | `apps/web/src/app/doctors/page.tsx`<br>`apps/web/src/app/api/doctors/route.ts`<br>`apps/web/src/app/api/doctors/[id]/route.ts`<br>`apps/web/src/components/common/ReferringDoctorSelect.tsx` | `PatientCardPanel.tsx`<br>`apps/web/src/app/patients/page.tsx`<br>`apps/web/src/app/financials/page.tsx` | `ReferringDoctor`<br>`Patient`<br>`Sample` | Foreign key constraint failure if doctor is deleted with associated samples; commission calculation errors in financial shift reports. |
| **Financials, Cash Shifts & Pricing** | `apps/web/src/app/financials/page.tsx`<br>`apps/web/src/app/api/financials/shifts/open/route.ts`<br>`apps/web/src/app/api/financials/shifts/close/route.ts`<br>`apps/web/src/app/api/financials/summary/route.ts`<br>`apps/web/src/lib/currencies.ts` | `UnifiedActionBar.tsx`<br>`apps/web/src/app/patients/page.tsx` | `CashDrawerShift`<br>`FinancialTransaction`<br>`Sample`<br>`Expense` | Shift closing with negative cash balance; currency conversion rounding discrepancy (IQD vs USD); double-crediting cash drawer on partial payments. |
| **Debts & Patient Ledgers** | `apps/web/src/app/debts/page.tsx`<br>`apps/web/src/app/api/debts/route.ts`<br>`apps/web/src/app/api/debts/[id]/transaction/route.ts`<br>`apps/web/src/app/api/debts/[id]/settle-all/route.ts` | `apps/web/src/app/patients/page.tsx`<br>`apps/web/src/app/financials/page.tsx` | `Debtor`<br>`DebtRecord`<br>`FinancialTransaction` | Debt records getting orphaned if sample is edited; transaction history mismatch between debtor ledger and cash drawer shift. |
| **Auto-Update & Distribution** | `apps/desktop/services/updateService.js`<br>`apps/web/src/components/common/UpdateNotificationBanner.tsx`<br>`apps/web/src/app/api/version/check/route.ts`<br>`packages/core/src/version.ts`<br>`tools/deploy/publish_desktop_release.js` | `apps/desktop/main.js`<br>`apps/web/src/components/AppShell.tsx` | N/A (`updater_settings.json` on disk) | Infinite update loop (`isLoopLocked`); legacy 32-bit machine downloading 64-bit NSIS setup; GitHub release tag mismatch with `packages/core/src/version.ts`. |
| **Desktop Startup, Offline Boot & Port Management** | `apps/desktop/main.js`<br>`apps/desktop/preload.js`<br>`apps/desktop/installer.nsh`<br>`apps/desktop/installer-legacy.nsh` | All desktop processes | N/A (SQLite file allocation) | Port collision (8080 occupied by IIS or other software); failure to fallback to alternative ports (`8085`, `8088`); SQLite file locked by antivirus during initial copy. |
| **Roles, Permissions & Staff Security** | `apps/server/src/routes/auth.ts`<br>`apps/server/src/utils/audit.ts`<br>`apps/web/src/app/staff/page.tsx`<br>`apps/web/src/app/api/staff/route.ts`<br>`apps/web/src/middleware.ts` | `AppShell.tsx`<br>`apps/web/src/components/TrialLockGuard.tsx` | `Staff`<br>`Session`<br>`AuditLog` | Session expiration during active test entry; technicians blocked from entering results; non-owner accessing financial reports; token expiration handling. |
| **LAN Multi-Workstation Sync (SSE)** | `apps/web/src/components/NetworkSyncProvider.tsx`<br>`apps/web/src/app/api/network/events/route.ts`<br>`apps/web/src/app/api/network/pair/route.ts`<br>`apps/web/src/lib/networkDeviceManager.ts` | `UnifiedWorkspace.tsx`<br>`apps/web/src/app/patients/page.tsx`<br>`apps/web/src/middleware.ts` | N/A (`network_devices.json` in `apps/web/data`) | SSE connection timeout causing false offline alerts; client tablets rejected by `middleware.ts` due to missing `x-device-token`; event ring-buffer dropped events. |
| **Medical Device Bridge (ASTM / HL7)** | `apps/desktop/services/deviceBridgeService.js`<br>`apps/server/src/services/tcpDeviceServer.ts`<br>`apps/server/src/utils/parsers/astmParser.ts`<br>`apps/server/src/utils/parsers/hl7Parser.ts`<br>`apps/web/src/app/api/devices/ingest/route.ts` | `apps/web/src/app/devices/page.tsx`<br>`ResultsGridPanel.tsx` | `LabDevice`<br>`DeviceTestMapping`<br>`IncomingResult`<br>`DeviceRawLog` | Malformed checksum in ASTM frames causing dropped packets; unmapped test codes discarding incoming results; TCP socket half-open freeze. |
| **WhatsApp Automated Sharing** | `apps/web/src/lib/shareReportToWhatsApp.ts`<br>`apps/web/src/lib/whatsappWebEngine.ts`<br>`apps/server/src/services/whatsappService.ts`<br>`apps/desktop/services/whatsappAutoPaste.ps1` | `apps/web/src/app/patients/page.tsx`<br>`UnifiedActionBar.tsx` | `Settings` (WhatsApp config) | Baileys multi-device protocol desync; Iraqi phone number format normalization failure (must prefix `964`); PowerShell clipboard paste focus loss. |

---

## 6. End-to-End Data Flows

### Workflow 1: Patient Registration → Result Entry → Printing & WhatsApp
```
1. [User enters patient info & tests in PatientCardPanel + CatalogCartPanel]
   │
   ├──> Client validates Age / Gender / Phone via ClinicalAgeInput & formatters.ts
   ├──> Calculates Pricing, Discounts (0-100% slider), and Payment Status
   └──> HTTP POST /api/samples
          │
          ├──> Prisma creates Patient (or links existing) and Sample in lab.db
          ├──> Prisma creates SampleTest records for each ordered test
          ├──> Server emits SSE Event: SAMPLE_CREATED to /api/network/events
          └──> Returns sampleId and sampleNumber (e.g. S-261101-001)

2. [Technician enters results in ResultsGridPanel]
   │
   ├──> Technician clicks test:
   │      ├─ Standard test ──> Inline numeric or qualitative pill selection
   │      └─ Specialized test ──> testClassifier.ts routes to dedicated modal
   │                               (UrineFormModal, GseModal, CbcModal, etc.)
   ├──> Reference range auto-matched via matchPatientReferenceRange(age, sex)
   ├──> Range evaluated: Normal, High, Low, or Critical Panic
   ├──> Delta check compares against patient's previous historical readings
   └──> HTTP PUT /api/samples/[id]/results
          │
          ├──> Prisma updates SampleTest.resultValue, flag, status='COMPLETED'
          └──> Server emits SSE Event: RESULTS_SAVED

3. [Print or WhatsApp Delivery]
   │
   ├──> Print:
   │      ├─ User clicks "Print Report" in UnifiedActionBar or PatientsPage
   │      ├─ HTTP GET /api/samples/[id]/print?autoprint=true
   │      ├─ Server resolves layout from Settings via PaperDesignerV2 rules
   │      ├─ PrintHeader.ts builds clinic header, logo, patient metadata box
   │      ├─ PrintBody.ts renders test groups, reference ranges, and flags
   │      └─ Output rendered directly to browser print dialog or Puppeteer PDF
   │
   └──> WhatsApp Send:
          ├─ User clicks "Send WhatsApp" in UnifiedActionBar
          ├─ shareReportToWhatsApp.ts checks 3 tiers:
          │    Tier 0: Baileys backend session -> POST /api/whatsapp/send-result
          │    Tier 1: Electron desktop app -> IPC generateReportImage & AutoPaste
          │    Tier 2: Browser fallback -> POST /api/whatsapp/share-desktop
          └─ Patient receives high-resolution image card directly on WhatsApp
```

### Workflow 2: Catalog Edit → Impact on Active Results & Printing
```
1. [Administrator edits test in apps/web/src/app/catalog/page.tsx]
   │
   ├──> Admin updates test nameEn, arabicName, price, or Reference Ranges
   └──> HTTP PUT /api/tests/[id]
          │
          ├──> Prisma updates TestCatalog record in lab.db
          ├──> Prisma updates or recreates ReferenceRange relational records
          ├──> Invalidates in-memory cache in apps/web/src/lib/catalogCache.ts
          └──> Server emits SSE Event: CATALOG_UPDATED

2. [Real-time Propagation to Active Consoles]
   │
   ├──> NetworkSyncProvider receives CATALOG_UPDATED event
   ├──> useUnifiedWorkspace hook invalidates local catalog state
   ├──> Existing unprinted samples dynamically re-evaluate reference ranges
   │    via resolveReferenceRange(sampleTest, patient.ageInDays, patient.gender)
   └──> Next print request to /api/samples/[id]/print automatically applies
        the new reference ranges and grouping configuration.
```

---

## 7. Known Pitfalls & Fragile Areas in the Codebase

1. **Dual Schema Files (`apps/server/prisma/schema.prisma` vs `apps/web/prisma/schema.prisma`):**
   - *Evidence:* Both files exist and must remain strictly in sync. The only permitted variance is `binaryTargets` in `apps/web/prisma/schema.prisma` for deployment compatibility.
   - *Risk:* If an engineer adds a column to `apps/server/prisma/schema.prisma` without updating `apps/web/prisma/schema.prisma` (or vice-versa), `prisma generate` will produce divergent TypeScript definitions, causing runtime query crashes.
2. **Runtime SQLite Schema Evolution vs Prisma Push (`apps/web/src/lib/prisma.ts`):**
   - *Evidence:* Lines 170-297 in `apps/web/src/lib/prisma.ts` execute imperative `PRAGMA user_version = 145` and `ALTER TABLE` statements.
   - *Risk:* In deployed desktop environments, Prisma CLI (`prisma db push`) is never executed at runtime. All new columns or tables MUST be added safely with additive SQL in `apps/web/src/lib/prisma.ts` under an incremented `CURRENT_SCHEMA_VERSION`.
3. **Hardcoded Test Name & Code Heuristics (`apps/web/src/lib/testClassifier.ts`):**
   - *Evidence:* Specialized form routing checks substrings (e.g. `'GUE'`, `'URINE'`, `'فحص الإدرار العام'`, `'C&S'`).
   - *Risk:* If a laboratory renames a test in the catalog to a non-standard name without these keywords, `testClassifier.ts` will fail to recognize it as a specialized test and will render the standard numeric grid instead of the specialized modal.
4. **JSON Serialization in `SampleTest.resultValue` (`apps/web/src/components/UrineFormModal.tsx`):**
   - *Evidence:* Complex forms (GUE, GSE, SFA) serialize an entire JSON object into the single text column `SampleTest.resultValue`.
   - *Risk:* If an engineer modifies the keys in `UrineTemplatesConfig` without backwards-compatible fallbacks, opening older patient samples will trigger React null-reference errors.
5. **Puppeteer Process Management on Windows (`apps/web/src/lib/puppeteerLauncher.ts`):**
   - *Evidence:* In Windows environments without Google Chrome installed, Puppeteer must locate the bundled Chromium binary in `LocalAppData` or `Program Files`.
   - *Risk:* If orphaned headless Chrome processes accumulate due to unhandled exceptions, local system memory can degrade. Always ensure `browser.close()` is in a `finally` block.
6. **Auto-Update Infinite Loop Hazards (`apps/desktop/services/updateService.js`):**
   - *Evidence:* `updateService.js` contains dedicated loop-prevention guards (`isLoopLocked`, `compareSemver`).
   - *Risk:* If a new release is published with a GitHub Release tag (e.g. `v2.1.0`) that does not match `package.json` (`2.1.0`), the desktop client will repeatedly download the update, install it, and check again immediately upon restart.

---

## 8. Development & Architectural Conventions

1. **Feature-Sliced Design (FSD) Rules:**
   - Strict layer hierarchy: `app › pages › widgets › features › entities › shared`.
   - Imports are strictly unidirectional downwards. Never import a feature into another feature, and never import from higher layers.
   - Each slice exposes its public interface exclusively via `index.ts`.
2. **Bilingual & English-Only UI Rules:**
   - Patient reports and laboratory result tables must strictly format clinical test names and categories in English (`getReportEnglishTestName` in `PrintHeader.ts` and `PrintBody.ts`).
   - If a test name contains Arabic characters, the system extracts the English name enclosed in parentheses `(e.g. Lipid Panel)` or falls back to the Latin test code.
   - User interface text and instructions are bilingual with primary Right-to-Left (RTL) Arabic layout (`dir="rtl"`).
3. **How to Add a New Clinical Test:**
   1. Add default entry in `packages/data/src/catalog/catalogData.ts`.
   2. Define reference ranges in `INITIAL_TESTS_CATALOG` with explicit `ageMin`, `ageMax`, `sex`, `low`, and `high`.
   3. The test is immediately available for ordering in the catalog and will auto-seed upon fresh initialization.
4. **How to Add a New Specialized Workstation Form:**
   1. Define form schema in `packages/forms/definitions/<form_name>.json`.
   2. Register classification rule in `apps/web/src/lib/testClassifier.ts` (`is<Name>Test`).
   3. Create modal component in `apps/web/src/components/workstations/<Name>Modal.tsx`.
   4. Add renderer branch in `apps/web/src/app/api/samples/[id]/print/PrintBody.ts` for print formatting.

---

## 9. Protected Areas (Do NOT Modify Without Explicit Architecture Review)

- **Database Schemas:** `apps/server/prisma/schema.prisma` and `apps/web/prisma/schema.prisma`.
- **Runtime SQLite Migration Engine:** `apps/web/src/lib/prisma.ts`.
- **Licensing & HWID Seal:** `apps/server/src/utils/licensing.ts` and `apps/web/src/lib/licensing.ts`.
- **Electron Boot & PE Loader Patches:** `apps/desktop/main.js` and `apps/desktop/installer*.nsh`.
- **WhatsApp Web Daemon:** `apps/server/src/services/whatsappService.ts` and `@whiskeysockets/baileys`.
- **Root Configuration Files:** `package.json`, `package-lock.json`, `tsconfig.json`, `next.config.js`.

---

## 10. Audit Log & Change Protocol

Whenever a structural change is made to the codebase:
1. Update ONLY affected sections in this document.
2. Refresh the **Last updated** header with the exact UTC timestamp.
3. Append a one-line summary to `CHANGELOG.md`.
4. Run `npm run verify` (`typecheck`, `lint:boundaries`, `test:golden`, `build`) before committing.
